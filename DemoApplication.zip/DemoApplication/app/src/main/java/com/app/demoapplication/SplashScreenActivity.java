package com.app.demoapplication;

import android.app.Activity;
import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Typeface;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewTreeObserver;
import android.view.WindowManager;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageButton;
import android.widget.ListPopupWindow;
import android.widget.ListView;
import android.widget.PopupWindow;
import android.widget.RelativeLayout;
import android.widget.TextView;
import android.widget.Toast;

import com.app.adapters.OptionsDropdownAdapter;
import com.app.adapters.SplashAdapter;
import com.app.models.ItemDataModel;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class SplashScreenActivity extends Activity {

    private TextView txtTitle;
    private ImageButton btnOptions;
    private GridView gridItemsList;
    private SplashAdapter splashAdapter;
    private Activity activity;
    private Typeface typefaceRegular;
    private EditText etSearch;
    private TextWatcher textWatcherSearch;
    private String currentLanguageCode = "en";

    private ListPopupWindow listPopupWindow;
    private PopupWindow popupSpecies;
    private OptionsDropdownAdapter myAdapter;
    private int lastSelectedItemPosition = 0;
    private int numberTypeWidth;
    private RelativeLayout rltLayoutParent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_screen);
        activity = this;
    }


    @Override
    protected void onResume() {
        super.onResume();
        initUI();
        setFonts();
        setListener();
        setCustomData();
    }

    private void initUI() {
        txtTitle = (TextView) findViewById(R.id.txt_title);
        txtTitle.setText(getResources().getString(R.string.products));
        btnOptions = (ImageButton) findViewById(R.id.btn_options);
        gridItemsList = (GridView) findViewById(R.id.grid_view_items);
        etSearch = (EditText) findViewById(R.id.et_search);
        typefaceRegular = Typeface.createFromAsset(activity.getApplicationContext().getAssets(), "RobotoCondensedRegular.ttf");

        rltLayoutParent = (RelativeLayout) findViewById(R.id.rlt_layout_main);
        rltLayoutParent.getViewTreeObserver()
                .addOnGlobalLayoutListener(new HomeLayoutListener());

        btnOptions.setOnTouchListener(new View.OnTouchListener() {
            @Override
            public boolean onTouch(View v, MotionEvent event) {

                popupSpecies.setFocusable(true);

                if (popupSpecies != null) {
                    popupSpecies.showAsDropDown(btnOptions, 0, 0);
                }
                return true;
            }
        });

    }

    private void setCustomData() {
        ArrayList<ItemDataModel> itemsList = new ArrayList<>();

        for (int i = 0; i < 15; i++) {
            ItemDataModel itemDataModel = new ItemDataModel();
            itemDataModel.setItemName(getResources().getString(R.string.item) + " " + i);
            itemDataModel.setPrice(getResources().getString(R.string.price) + " : ₹" + i);
            itemsList.add(itemDataModel);
        }

        splashAdapter = new SplashAdapter(activity, itemsList);
        gridItemsList.setAdapter(splashAdapter);
    }

    private void setFonts() {
        txtTitle.setTypeface(typefaceRegular);
        etSearch.setTypeface(typefaceRegular);
    }

    private void setListener() {

        textWatcherSearch = new TextWatcher() {

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                if (splashAdapter != null) {
                    splashAdapter.getFilter().filter(s);
                }

            }

            @Override
            public void beforeTextChanged(CharSequence s, int start, int count,
                                          int after) {

            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        };

        etSearch.addTextChangedListener(textWatcherSearch);
    }

    private void switchLanguage(String languageSelected) {
        Locale locale = new Locale(languageSelected);
        Configuration config = new Configuration();
        config.locale = locale;
        activity.getApplicationContext().getResources().updateConfiguration(config, null);
        onResume();
    }

    private class HomeLayoutListener implements ViewTreeObserver.OnGlobalLayoutListener {
        @Override
        public void onGlobalLayout() {

            numberTypeWidth = btnOptions.getWidth();

            numberTypeWidth = 300;

            popupSpecies = popupSpecies();

        }
    }

    private PopupWindow popupSpecies() {

        final PopupWindow popupWindow = new PopupWindow(activity);
        popupWindow.setOutsideTouchable(true);
        popupWindow.setTouchable(true);
        popupWindow.setFocusable(true);

        ListView listViewLanguage = new ListView(activity);

        final List<String> listOptions = new ArrayList<String>();

        listOptions.add("English");
        listOptions.add("Portuguese");

        myAdapter = new OptionsDropdownAdapter(activity, listOptions, lastSelectedItemPosition);

        listViewLanguage.setAdapter(myAdapter);

        listViewLanguage.setSelection(lastSelectedItemPosition);

        listViewLanguage.setOnItemClickListener(new AdapterView.OnItemClickListener() {

            @Override
            public void onItemClick(AdapterView<?> arg0, View v, int position,
                                    long arg3) {
                Animation fadeInAnimation = AnimationUtils.loadAnimation(
                        v.getContext(), android.R.anim.fade_in);
                fadeInAnimation.setDuration(10);
                v.startAnimation(fadeInAnimation);

                if (listOptions.get(position).toString().trim().equalsIgnoreCase("English")) {
                    currentLanguageCode = "en";
                } else {
                    currentLanguageCode = "pt";
                }

                //            TODO Switch language as per selection
                switchLanguage(currentLanguageCode);
                if (currentLanguageCode.equalsIgnoreCase("en")) {
                    Toast.makeText(activity, getResources().getString(R.string.language_changed_to_english), Toast.LENGTH_LONG).show();
                    etSearch.setHint("Search Products");
                } else {
                    Toast.makeText(activity, getResources().getString(R.string.language_changed_to_portuguese), Toast.LENGTH_LONG).show();
                    etSearch.setHint("Procurar produtos");
                }

                lastSelectedItemPosition = position;

                popupWindow.dismiss();

            }
        });

        popupWindow.setOnDismissListener(new PopupWindow.OnDismissListener() {
            @Override
            public void onDismiss() {

            }
        });

        popupWindow.setWidth(numberTypeWidth);
        popupWindow.setHeight(WindowManager.LayoutParams.WRAP_CONTENT);

        btnOptions.setFocusable(true);
        btnOptions.setFocusableInTouchMode(true);

        popupWindow.setContentView(listViewLanguage);

        popupWindow
                .setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_RESIZE);

        return popupWindow;
    }

    public static void hideSoftKeyboard(Activity activity) {
        InputMethodManager inputMethodManager = (InputMethodManager) activity.getSystemService(Activity.INPUT_METHOD_SERVICE);
        inputMethodManager.hideSoftInputFromWindow(activity.getCurrentFocus().getWindowToken(), 0);
    }

    // To Hide Keyboard on outside Touch
    @Override
    public boolean dispatchTouchEvent(MotionEvent event) {
        View view = getCurrentFocus();
        boolean ret = super.dispatchTouchEvent(event);

        if (view instanceof EditText) {
            View w = getCurrentFocus();
            int scrcoords[] = new int[2];
            w.getLocationOnScreen(scrcoords);
            float x = event.getRawX() + w.getLeft() - scrcoords[0];
            float y = event.getRawY() + w.getTop() - scrcoords[1];

            if (event.getAction() == MotionEvent.ACTION_UP && (x < w.getLeft() || x >= w.getRight() || y < w.getTop() || y > w.getBottom())) {
                InputMethodManager imm = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
                imm.hideSoftInputFromWindow(getWindow().getCurrentFocus().getWindowToken(), 0);
            }
        }
        return ret;
    }


}
