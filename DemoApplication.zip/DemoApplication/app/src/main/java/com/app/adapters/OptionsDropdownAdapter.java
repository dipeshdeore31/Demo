package com.app.adapters;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.TextView;

import com.app.demoapplication.R;

import java.util.List;

public class OptionsDropdownAdapter extends BaseAdapter {

    private Context context;
    private List<String> optionsList;
    private LayoutInflater inflater;
    private int selectedPosition;

    public OptionsDropdownAdapter(Context context, List<String> objects, int lastSelectedItemPosition) {
        super();
        this.context = context;
        this.optionsList = objects;
        selectedPosition = lastSelectedItemPosition;

        this.inflater = (LayoutInflater) context
                .getSystemService(Context.LAYOUT_INFLATER_SERVICE);

    }


    @Override
    public int getCount() {
        return optionsList.size();

    }

    @Override
    public Object getItem(int position) {
        return null;
    }

    @Override
    public long getItemId(int position) {
        return 0;
    }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        ViewHolder holder;
        if (convertView == null) {
            holder = new ViewHolder();
            convertView = inflater.inflate(R.layout.row_item, null);

            holder.txtSpeciesItem = (TextView) convertView
                    .findViewById(R.id.txt_row);

            convertView.setTag(holder);
        } else
            holder = (ViewHolder) convertView.getTag();


        holder.txtSpeciesItem.setText(optionsList.get(position).toString());

        return convertView;
    }


    public static class ViewHolder {
        TextView txtSpeciesItem;
    }
}

